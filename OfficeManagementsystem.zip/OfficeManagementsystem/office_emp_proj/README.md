# Office-Employees-Management-System-OEMS-Django-Project
This is a Python-Django project from the scratch. In this , I create a project named "Office Employees Management System (OEMS)" from the scratch. It will cover many topics that will be helpful for you in order to clear the skills like Python, Django Framework, Django ORM, Django Queryset, Basic SQL (Database Knowledge), Basic HTML, CSS &amp; Basic Bootstrap. 

### Check the complete project code in the master branch 
